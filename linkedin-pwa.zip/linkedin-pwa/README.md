# LI Planner — LinkedIn Post Generator
### Matteo Grandi · Verdalia Bio

PWA installabile come app nativa su desktop e iPhone.

---

## 📦 Contenuto
```
linkedin-pwa/
├── index.html        ← App completa
├── manifest.json     ← Config PWA
├── sw.js             ← Service worker (offline)
└── icons/
    ├── icon-192.svg
    └── icon-512.svg
```

---

## 🚀 Deploy su GitHub Pages (5 minuti)

### Step 1 — Crea repo GitHub
1. Vai su **github.com** → New repository
2. Nome: `linkedin-planner` (o qualsiasi)
3. Spunta "Public"
4. Clicca "Create repository"

### Step 2 — Carica i file
1. Clicca "uploading an existing file"
2. Trascina TUTTA la cartella `linkedin-pwa` (tutti i file + sottocartella icons)
3. Commit changes

### Step 3 — Attiva GitHub Pages
1. Settings → Pages (menu laterale)
2. Source: "Deploy from a branch"
3. Branch: `main` → Folder: `/ (root)`
4. Save

### Step 4 — Attendi ~2 minuti
Il sito sarà live su:
`https://[tuousername].github.io/linkedin-planner/`

---

## 📲 Installazione app

### Su Mac (Chrome/Edge)
- Apri l'URL → clicca l'icona ⬇ nella barra URL → "Installa"

### Su iPhone (Safari)
- Apri l'URL in Safari → tocca Condividi → "Aggiungi a schermata Home"

### Su Android (Chrome)
- Apri l'URL → banner automatico "Installa app"

---

## ✦ Funzionalità
- **Genera Post** — AI ottimizzata per la tua voce (Verdalia Bio · M&A · Biomethane)
- **Campagna H2 2026** — 50 post Lun/Gio Jul–Dic, generabili con un tap
- **Calendario** — Vista mensile con tutti i post
- **Export .ics** — Importa in Apple Calendar / Google Calendar
- **Offline** — Funziona senza connessione (tranne generazione AI)
